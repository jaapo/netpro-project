void print_hello();
void start_connect();
void prompt_loop();
void change_dir(char *args, int arglen);
void working_dir(char *args, int arglen);
void list_dir(char *args, int arglen);
void client_quit();
void new_file(char *args, int arglen);
void edit_file(char *args, int arglen);
void read_file(char *args, int arglen);

